import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {parseIVTFF,project} from './site/analysis.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const registry=JSON.parse(fs.readFileSync(new URL('./corpus-sources.json',import.meta.url)));
const dir=new URL('./site/corpus/',import.meta.url);
const corpora=[];
for(const s of registry.sources){
  const bytes=fs.readFileSync(new URL('raw/'+s.file,dir));
  if(hash(bytes)!==s.sha256)throw new Error('Source checksum mismatch '+s.file);
  const c=parseIVTFF(bytes.toString('utf8'),s.id);
  c.source=s;c.bytes=bytes.length;c.summary={pages:c.pages.length,loci:c.loci.length,paragraphLoci:c.loci.filter(l=>l.type==='P0').length};
  for(const policy of ['strict','first-reading']){
    const ps=c.loci.filter(l=>l.type==='P0').map(l=>project(l.raw,policy));
    c.summary[policy]={candidates:ps.reduce((a,p)=>a+p.candidates,0),retained:ps.reduce((a,p)=>a+p.retained,0),rejected:ps.reduce((a,p)=>a+p.rejected.length,0)};
  }
  corpora.push(c);
  fs.writeFileSync(new URL(s.id+'.json',dir),JSON.stringify(c));
}
const yaleBytes=fs.readFileSync(new URL('raw/yale-2002046-manifest.json',dir)),yale=JSON.parse(yaleBytes);
const plain=o=>Object.values(o||{}).flat().join(' ');
const canvases=yale.items.map((c,i)=>{
  const body=c.items[0].items[0].body,label=plain(c.label);
  return {index:i,id:c.id,label,folioSides:[...new Set([...label.matchAll(/\b(\d+[rv])\b/g)].map(m=>'f'+m[1]))],image:body.id,thumbnail:c.thumbnail?.[0]?.id,width:body.width,height:body.height};
});
const manifest={schema:'codex-manifest/v1',version:'0.2.0-rc.1',retrieved:registry.retrieved,licence:registry.license,acquisition:registry.acquisition,sources:corpora.map(c=>({...c.source,bytes:c.bytes,summary:c.summary,parsedSha256:hash(fs.readFileSync(new URL(c.id+'.json',dir)))})),yale:{url:yale.id,catalog:'https://collections.library.yale.edu/catalog/2002046',sha256:hash(yaleBytes),canvases:canvases.length,attribution:'Cipher manuscript (Voynich manuscript). General Collection, Beinecke Rare Book and Manuscript Library, Yale University.',imagePolicy:'Image URLs are indexed; full scans are not bundled. Images load on demand from Yale. Canvas labels are preserved; folio-side matches are label-derived candidates, not verified panel coordinates.',rights:'https://library.yale.edu/policies/reuse'},canvases};
fs.writeFileSync(new URL('manifest.json',dir),JSON.stringify(manifest,null,2));
console.log(JSON.stringify(manifest.sources.map(s=>({id:s.id,...s.summary})),null,2));
console.log('Yale canvases',canvases.length);
