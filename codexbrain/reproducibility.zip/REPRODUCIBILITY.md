# Codex Voynich reproducibility

Release candidate 0.2.0-rc.1 includes two byte-pinned transliterations, the Yale manuscript canvas manifest, loss-aware parsed records, a frozen structural-test protocol and archived results. These are analytical observations, not a reading of the manuscript.

## Run locally

Use Node.js 20 or later. The reproduction bundle has no package dependencies and needs no credentials or network access for these commands.

```sh
node --test test-analysis.mjs
node ingest.mjs
node reproduce.mjs --verify
```

The final command recomputes all 16 comparisons and requires exact agreement with the archived result file. Running `node reproduce.mjs` without `--verify` writes a new result file; preserve the original before changing the implementation or protocol.

## Source provenance

- **ZL:** Zandbergen–Landini, version 3b of 13 May 2025, original [ZL3b-n.txt](https://www.voynich.nu/data/ZL3b-n.txt). Original-byte SHA-256: `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`.
- **IT:** Takeshi Takahashi, version 2a of 2 February 2023, modified 25 June 2025, original [IT2a-n.txt](https://www.voynich.nu/data/IT2a-n.txt). Original-byte SHA-256: `7f27a8b0feed8f6de0a99900df6bf912dd1d295c38e5f830bac8b41c3f536fb5`.
- **Acquisition:** Byte-preserving retrieval from the `noah-chelednik/voynich-data` archive at immutable commit `ecd4c8145524d90373535ea3d1617d8190dc8208`; original headers and publication/rights pages were checked separately. This is a pinned snapshot, not a claim that it will always be the latest edition.
- **Rights:** Voynich.nu explicitly supplies the collected transliterations under CC0; no EVA font or third-party VCAT annotations are bundled ([Voynich.nu licensing](https://www.voynich.nu/roadmap.html)).
- **Images:** The [Yale catalog](https://collections.library.yale.edu/catalog/2002046) identifies Beinecke MS 408 and its digital manuscript. The original IIIF manifest is stored, but full-resolution scans are not bundled; the app requests them from Yale on demand.

## Protocol and transformations

The JSON protocol is authoritative. It was committed locally before the first suite execution at `10e253c`; a parser correction to recognize `fRos`, grouped with f85/f86, followed at `2a8d0bd` before execution. This is a local freeze, not an independently registered study.

All non-comment source lines must parse or ingestion fails. Raw locus text, source line numbers, locators and page metadata survive ingestion. Parsing does not equate metadata labels with ground truth. The interpretation of spaces, uncertain spaces, alternatives and ligatures follows the [IVTFF documentation](https://www.voynich.nu/extra/sp_transcr.html).

Only P0 loci with IDs present in both readings enter the tests. Matching IDs do not guarantee exact character alignment. The strict projection retains lowercase a–z candidates only; rejected candidates interrupt adjacency runs. The first-reading projection is one sensitivity analysis, not an editorial correction.

Recto, verso and panel IDs share their folio-number group. f85, f86 and fRos are conservatively grouped together. A deterministic FNV-1a rule assigns groups to development or heldout partitions. These groups are not asserted to be statistically independent or a complete physical codicological reconstruction.

H1 tests excess adjacent-token repetition against within-page token shuffling. H2 tests lower within-token conditional character entropy against independent within-token character shuffling. The suite uses xorshift32, Fisher–Yates shuffling, 499 permutations, inclusive one-sided tails, plus-one Monte Carlo p-values and Holm correction across all 16 comparisons. Numerical outputs are rounded to 10 decimal places; browser parity is defined at this recorded precision.

## Limits and negative claims

- **Meaning:** None of these measurements tests a translation or establishes a language, cipher, author or message.
- **Dependence:** Two readings of one manuscript are not independent evidence. IT’s two policies may produce identical tokens; separate fixed seeds can still produce different Monte Carlo null samples.
- **Selection:** Strict uncertainty exclusions are not missing at random. The sensitivity policy does not exhaust all possible readings.
- **Holdout use:** The heldout results are now revealed and cannot serve as an untouched test set for a future tuned hypothesis.
- **Comparators:** Natural-language corpora, machine emulators, a decipherment engine and a replication of the published singulion study are not included.
- **Integrity:** Hashes detect accidental mismatch against the bundled manifest. They are not a digital signature, proof of authenticity or independent attestation.
