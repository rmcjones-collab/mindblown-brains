import test from 'node:test';
import assert from 'node:assert/strict';
import {parseIVTFF,project,partitionFor,groupFor,random,shuffle,repeatStat,entropyStat,holm} from './site/analysis.mjs';
test('IVTFF retains raw uncertainty and metadata',()=>{
  const c=parseIVTFF('#=IVTFF Eva- 2.0 M 5\n<f1r> <! $L=A $H=1>\n<f1r.1,@P0> <%>ab.[a:o].c?d<$>\n','fixture');
  assert.equal(c.pages[0].metadata.L,'A');assert.equal(c.loci[0].raw,'<%>ab.[a:o].c?d<$>');assert.equal(c.loci[0].type,'P0');
});
test('parser rejects silently lost lines and duplicate loci',()=>{
  assert.throws(()=>parseIVTFF('#=IVTFF\nnonsense','x'));
  assert.throws(()=>parseIVTFF('#=IVTFF\n<f1r>\n<f1r.1,@P0> a\n<f1r.1,@P0> b','x'));
});
test('strict uncertainty breaks adjacency, without fabricating neighbours',()=>{
  assert.deepEqual(project('ab.[a:o].ab.a,b.{ch}.Ab.@185;.c?d').runs,[['ab'],['ab']]);
  assert.equal(project('ab.[a:o].ab.a,b.{ch}.Ab.@185;.c?d').rejected.length,6);
});
test('explicit sensitivity projection and interruption boundaries',()=>{
  assert.deepEqual(project('<%>Ab<!note>.[a:o].{ch}.a,b<->cd<$>','first-reading').runs,[['ab','a','ch','a','b'],['cd']]);
});
test('recto verso panels and rosette foldout never leak across split',()=>{
  for(let i=1;i<117;i++)assert.equal(partitionFor('f'+i+'r1'),partitionFor('f'+i+'v2'));
  assert.equal(groupFor('f85v'),groupFor('f86r'));assert.equal(partitionFor('f85v'),partitionFor('f86r'));
  assert.equal(groupFor('fRos'),groupFor('f85v'));
});
test('seeded shuffle is deterministic and preserves inventory',()=>{
  const a=shuffle([1,2,3,4,5,6],random(42)),b=shuffle([1,2,3,4,5,6],random(42));
  assert.deepEqual(a,b);assert.deepEqual([...a].sort(),[1,2,3,4,5,6]);
  assert.equal(random(1)(),270369/4294967296);
});
test('known statistics and no-pair cases',()=>{
  assert.equal(repeatStat([{runs:[['a','a','b']]}]).value,.5);
  assert.equal(repeatStat([{runs:[['a'],['a']]}]).value,null);
  assert.equal(entropyStat([{runs:[['ab','ab','ab']]}]),0);
  assert.equal(entropyStat([{runs:[['ab','ac']]}]),1);
  assert.equal(entropyStat([{runs:[['a']]}]),null);
});
test('Holm adjustment is monotone in sorted p, handles ties',()=>{
  assert.deepEqual(holm([.01,.04,.03]),[.03,.06,.06]);
  assert.deepEqual(holm([.002,.002,1]),[.006,.006,1]);
});
