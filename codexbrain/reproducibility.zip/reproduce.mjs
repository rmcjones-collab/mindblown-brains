import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {runSuite} from './site/analysis.mjs';
const dir=new URL('./site/corpus/',import.meta.url);
const hash=b=>createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(fs.readFileSync(new URL('manifest.json',dir)));
const corpora=manifest.sources.map(s=>{
  const raw=fs.readFileSync(new URL('raw/'+s.file,dir)),parsed=fs.readFileSync(new URL(s.id+'.json',dir));
  if(hash(raw)!==s.sha256||hash(parsed)!==s.parsedSha256)throw new Error('Integrity failure '+s.id);
  return JSON.parse(parsed);
});
const protocolBytes=fs.readFileSync(new URL('protocol.json',dir)),protocol=JSON.parse(protocolBytes);
const result=await runSuite(corpora,protocol,p=>{if(p.permutation===499)console.log(`${p.completed}/16 ${p.comparison}`);});
result.inputs={protocolSha256:hash(protocolBytes),implementationSha256:hash(fs.readFileSync(new URL('./site/analysis.mjs',import.meta.url))),sources:manifest.sources.map(s=>({id:s.id,sha256:s.sha256,parsedSha256:s.parsedSha256}))};
const record={...result,resultSha256:hash(JSON.stringify(result))};
const output=new URL('results.json',dir),bytes=JSON.stringify(record,null,2)+'\n';
if(process.argv.includes('--verify')){
  if(fs.readFileSync(output,'utf8')!==bytes)throw new Error('Result bytes differ from archived record');
  console.log('PASS: exact archived result bytes reproduced',record.resultSha256);
}else{fs.writeFileSync(output,bytes);console.log('Saved',record.resultSha256);}
